import logging
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    ConversationHandler, filters, ContextTypes
)

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# --- КОНФІГ ---
BOT_TOKEN = os.getenv("BOT_TOKEN", "ВАШ_ТОКЕН_ТУТ")
MANAGER_CHAT_ID = os.getenv("MANAGER_CHAT_ID", "ВАШ_CHAT_ID_ТУТ")  # твій особистий chat_id

# --- СТАНИ РОЗМОВИ ---
(
    ASK_NAME,
    ASK_TELEGRAM,
    ASK_POSITION,
    ASK_POSITION_CUSTOM,
    ASK_INTERVIEW_LINK,
    ASK_LIKED,
    ASK_DOUBTS,
    ASK_IMPRESSION,
    ASK_RECOMMEND,
    ASK_DECISION,
) = range(10)

POSITIONS = ["Менеджер з продажу", "Kids менеджер", "Інша позиція"]


# --- СТАРТ ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    recruiter = update.effective_user.first_name
    await update.message.reply_text(
        f"Привіт, {recruiter}! 👋\n\n"
        "Заповнюємо звіт по співбесіді.\n"
        "Це займе 2-3 хвилини.\n\n"
        "➡️ *ПІБ кандидата?*",
        parse_mode="Markdown"
    )
    return ASK_NAME


# --- КРОК 1: ПІБ ---
async def ask_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["candidate_name"] = update.message.text.strip()
    await update.message.reply_text(
        "📱 *Telegram кандидата* (нік @username або номер телефону):",
        parse_mode="Markdown"
    )
    return ASK_TELEGRAM


# --- КРОК 2: TELEGRAM ---
async def ask_telegram(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["candidate_telegram"] = update.message.text.strip()

    keyboard = [[pos] for pos in POSITIONS]
    reply_markup = ReplyKeyboardMarkup(keyboard, one_time_keyboard=True, resize_keyboard=True)
    await update.message.reply_text(
        "💼 *Позиція* — обери або напиши свою:",
        parse_mode="Markdown",
        reply_markup=reply_markup
    )
    return ASK_POSITION


# --- КРОК 3: ПОЗИЦІЯ ---
async def ask_position(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if text == "Інша позиція":
        await update.message.reply_text(
            "✏️ Напиши назву позиції:",
            reply_markup=ReplyKeyboardRemove()
        )
        return ASK_POSITION_CUSTOM

    context.user_data["position"] = text
    await update.message.reply_text(
        "🎥 *Запис співбесіди*\n\nВідправ посилання (Zoom, Google Meet тощо), файл або голосове повідомлення.\n\nЯкщо немає — напиши: *немає*",
        parse_mode="Markdown",
        reply_markup=ReplyKeyboardRemove()
    )
    return ASK_INTERVIEW_LINK


async def ask_position_custom(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["position"] = update.message.text.strip()
    await update.message.reply_text(
        "🎥 *Запис співбесіди*\n\nВідправ посилання, файл або голосове.\nЯкщо немає — напиши: *немає*",
        parse_mode="Markdown"
    )
    return ASK_INTERVIEW_LINK


# --- КРОК 4: ЗАПИС ---
async def ask_interview_link(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text:
        context.user_data["interview_record"] = update.message.text.strip()
    elif update.message.voice:
        context.user_data["interview_record"] = f"[голосове повідомлення, file_id: {update.message.voice.file_id}]"
    elif update.message.document:
        context.user_data["interview_record"] = f"[файл: {update.message.document.file_name}]"
    elif update.message.video:
        context.user_data["interview_record"] = f"[відео файл]"
    else:
        context.user_data["interview_record"] = "не надано"

    await update.message.reply_text(
        "💬 *Коментар рекрутера — Частина 1*\n\n"
        "👉 Що *сподобалось* у кандидата?\n\n"
        "Напиши розгорнуто:",
        parse_mode="Markdown"
    )
    return ASK_LIKED


# --- КРОК 5: ЩО СПОДОБАЛОСЬ ---
async def ask_liked(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["liked"] = update.message.text.strip()
    await update.message.reply_text(
        "💬 *Коментар рекрутера — Частина 2*\n\n"
        "👉 Що *викликало сумніви* або не підійшло?\n\n"
        "Напиши розгорнуто:",
        parse_mode="Markdown"
    )
    return ASK_DOUBTS


# --- КРОК 6: СУМНІВИ ---
async def ask_doubts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["doubts"] = update.message.text.strip()
    await update.message.reply_text(
        "💬 *Коментар рекрутера — Частина 3*\n\n"
        "👉 *Загальне враження* від кандидата?\n\n"
        "Напиши розгорнуто:",
        parse_mode="Markdown"
    )
    return ASK_IMPRESSION


# --- КРОК 7: ВРАЖЕННЯ ---
async def ask_impression(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["impression"] = update.message.text.strip()
    await update.message.reply_text(
        "💬 *Коментар рекрутера — Частина 4*\n\n"
        "👉 Чи *рекомендуєш* кандидата далі і чому?\n\n"
        "Напиши розгорнуто:",
        parse_mode="Markdown"
    )
    return ASK_RECOMMEND


# --- КРОК 8: РЕКОМЕНДАЦІЯ ---
async def ask_recommend(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["recommend"] = update.message.text.strip()

    keyboard = [
        [InlineKeyboardButton("✅ Далі", callback_data="decision_forward")],
        [InlineKeyboardButton("⚠️ Під питанням", callback_data="decision_maybe")],
        [InlineKeyboardButton("❌ Відмова", callback_data="decision_reject")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        "🏁 *Фінальне рішення по кандидату:*",
        parse_mode="Markdown",
        reply_markup=reply_markup
    )
    return ASK_DECISION


# --- КРОК 9: РІШЕННЯ + ВІДПРАВКА ЗВІТУ ---
async def ask_decision(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    decisions = {
        "decision_forward": "✅ Далі",
        "decision_maybe": "⚠️ Під питанням",
        "decision_reject": "❌ Відмова",
    }
    context.user_data["decision"] = decisions.get(query.data, "не вказано")

    recruiter = query.from_user.first_name
    recruiter_username = f"@{query.from_user.username}" if query.from_user.username else query.from_user.first_name
    d = context.user_data

    # --- ФОРМУЄМО ЗВІТ ---
    decision_emoji = d["decision"].split()[0]
    report = (
        f"📋 *ЗВІТ ПО СПІВБЕСІДІ*\n"
        f"{'─' * 30}\n\n"
        f"👤 *Кандидат:* {d.get('candidate_name', '—')}\n"
        f"📱 *Telegram:* {d.get('candidate_telegram', '—')}\n"
        f"💼 *Позиція:* {d.get('position', '—')}\n"
        f"🎥 *Запис:* {d.get('interview_record', '—')}\n\n"
        f"{'─' * 30}\n"
        f"💬 *КОМЕНТАР РЕКРУТЕРА*\n\n"
        f"👍 *Що сподобалось:*\n{d.get('liked', '—')}\n\n"
        f"⚠️ *Сумніви / не підійшло:*\n{d.get('doubts', '—')}\n\n"
        f"💡 *Загальне враження:*\n{d.get('impression', '—')}\n\n"
        f"🔄 *Рекомендація:*\n{d.get('recommend', '—')}\n\n"
        f"{'─' * 30}\n"
        f"🏁 *РІШЕННЯ: {d.get('decision', '—')}*\n\n"
        f"{'─' * 30}\n"
        f"👨‍💼 *Рекрутер:* {recruiter_username}\n"
    )

    # Підтвердження рекрутеру
    await query.edit_message_text(
        f"*Рішення збережено: {d['decision']}*\n\nЗвіт відправлено керівнику. Дякую! 🙌",
        parse_mode="Markdown"
    )

    # Відправка керівнику
    try:
        await context.bot.send_message(
            chat_id=MANAGER_CHAT_ID,
            text=report,
            parse_mode="Markdown"
        )
        logger.info(f"Звіт по {d.get('candidate_name')} відправлено керівнику")
    except Exception as e:
        logger.error(f"Помилка відправки керівнику: {e}")

    context.user_data.clear()
    return ConversationHandler.END


# --- СКАСУВАННЯ ---
async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    await update.message.reply_text(
        "Заповнення скасовано. Напиши /start щоб почати знову.",
        reply_markup=ReplyKeyboardRemove()
    )
    return ConversationHandler.END


# --- ХЕЛП ---
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "ℹ️ *Команди бота:*\n\n"
        "/start — розпочати заповнення звіту\n"
        "/cancel — скасувати заповнення\n"
        "/help — ця підказка",
        parse_mode="Markdown"
    )


# --- ЗАПУСК ---
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            ASK_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_name)],
            ASK_TELEGRAM: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_telegram)],
            ASK_POSITION: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_position)],
            ASK_POSITION_CUSTOM: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_position_custom)],
            ASK_INTERVIEW_LINK: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, ask_interview_link),
                MessageHandler(filters.VOICE, ask_interview_link),
                MessageHandler(filters.Document.ALL, ask_interview_link),
                MessageHandler(filters.VIDEO, ask_interview_link),
            ],
            ASK_LIKED: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_liked)],
            ASK_DOUBTS: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_doubts)],
            ASK_IMPRESSION: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_impression)],
            ASK_RECOMMEND: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_recommend)],
            ASK_DECISION: [CallbackQueryHandler(ask_decision, pattern="^decision_")],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True,
    )

    app.add_handler(conv_handler)
    app.add_handler(CommandHandler("help", help_command))

    logger.info("Бот запущено...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
